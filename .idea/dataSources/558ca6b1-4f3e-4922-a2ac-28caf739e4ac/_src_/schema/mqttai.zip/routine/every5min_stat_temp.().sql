CREATE PROCEDURE `every5min_stat_temp`()
  BEGIN
	
	declare v_mintemp INTEGER(11) DEFAULT 0;
	declare v_maxtemp INTEGER(11) DEFAULT 0;
	declare v_avgtemp DOUBLE DEFAULT 0.0;
	declare v_tempnums INTEGER DEFAULT 0;
	
	DECLARE v_minhumi INT(11) DEFAULT 0;
	DECLARE v_maxhumi INT(11) DEFAULT 0;
	DECLARE v_avghumi DOUBLE DEFAULT 0.0;
	DECLARE v_huminums INT(11) DEFAULT 0;
	
	DECLARE v_minairp INTEGER DEFAULT 0;
	DECLARE v_maxairp INTEGER DEFAULT 0;
	DECLARE v_avgairp DOUBLE DEFAULT 0.0;
	DECLARE v_airpnums INTEGER DEFAULT 0;
	
	DECLARE v_minillu INT(11) DEFAULT 0;
	DECLARE v_maxillu INT(11) DEFAULT 0;
	DECLARE v_avgillu DOUBLE DEFAULT 0.0;
	DECLARE v_illunums INT(11) DEFAULT 0;
	
	SET @BeginTime = UNIX_TIMESTAMP(NOW()); -- 从整点开始，便于5分钟汇聚规律
	-- WHILE @BeginTime < UNIX_TIMESTAMP(NOW()) DO
	
		select                                                    
		 MIN(temp), MAX(temp), AVG(temp),count(*)  
		into v_mintemp, v_maxtemp, v_avgtemp, v_tempnums from sensorrecord_new 
		where TYPE =2 and UNIX_TIMESTAMP(local_time) >= @BeginTime - 300 and UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(humi), MAX(humi), AVG(humi),COUNT(*)  
		INTO v_minhumi, v_maxhumi, v_avghumi, v_huminums FROM sensorrecord_new 
		WHERE TYPE =2 ='temphumi' AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 300 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(hr_press), MAX(hr_press), AVG(hr_press),COUNT(*)  
		INTO v_minairp, v_maxairp, v_avgairp, v_airpnums FROM sensorrecord_new 
		WHERE TYPE =5 AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 300 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		SELECT                                                    
		 MIN(illu), MAX(illu), AVG(illu),COUNT(*)  
		INTO v_minillu, v_maxillu, v_avgillu, v_illunums FROM sensorrecord_new 
		WHERE TYPE =4 AND UNIX_TIMESTAMP(local_time) >= @BeginTime - 300 AND UNIX_TIMESTAMP(local_time) < @BeginTime;
		
		insert into statistic_temp (mintemp,maxtemp,avgtemp,tempnums,minhumi,maxhumi,avghumi,huminums,
		minairp,maxairp,avgairp,airpnums,minillu,maxillu,avgillu,illunums,recordtime)
		VALUES(v_mintemp, v_maxtemp, v_avgtemp, v_tempnums,
		v_minhumi, v_maxhumi, v_avghumi, v_huminums,
		v_minairp, v_maxairp, v_avgairp, v_airpnums,
		v_minillu, v_maxillu, v_avgillu, v_illunums,
		DATE_FORMAT(FROM_UNIXTIME(@BeginTime), "%Y-%m-%d %H:%i:%S"));
		-- SET @BeginTime = @BeginTime + 300;  -- 5分钟的跨度相加
	-- END WHILE;
	
    END